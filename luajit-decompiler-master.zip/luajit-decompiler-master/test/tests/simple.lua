function gethello()
	return "Hello, World"
end

print(gethello())
