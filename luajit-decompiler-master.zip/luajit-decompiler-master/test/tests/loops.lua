for i=1,10,2 do
	print(i)
end
