#
# Copyright (C) 2013 Andrian Nord. See Copyright Notice in main.py
#

# The currently selected LuaJIT bytecode version we're reading
CURRENT_VERSION = None
