#
# Copyright (C) 2013 Andrian Nord. See Copyright Notice in main.py
#
